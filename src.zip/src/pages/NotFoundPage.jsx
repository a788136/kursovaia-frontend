export default function NotFoundPage() {
  return <h1 className="text-red-600 text-xl">404 — Страница не найдена</h1>;
}
