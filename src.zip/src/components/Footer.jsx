export default function Footer() {
  return (
    <footer className="bg-gray-100 text-center text-xs py-2">
      &copy; 2025 Inventory App
    </footer>
  );
}